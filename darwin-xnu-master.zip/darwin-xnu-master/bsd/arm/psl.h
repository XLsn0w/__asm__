/*
 * Copyright (c) 2000-2007 Apple Inc. All rights reserved.
 */
/*
 * Copyright (c) 1992 NeXT Computer, Inc.
 *
 */
 
#if	KERNEL_PRIVATE

#ifndef _BSD_ARM_PSL_H_
#define _BSD_ARM_PSL_H_
 
#endif	/* _BSD_ARM_PSL_H_ */

#endif	/* KERNEL_PRIVATE */

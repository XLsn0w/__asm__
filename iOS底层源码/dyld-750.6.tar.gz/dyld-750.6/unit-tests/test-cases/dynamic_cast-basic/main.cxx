
extern void realmain();

int main()
{
	realmain();
	return 0;
}



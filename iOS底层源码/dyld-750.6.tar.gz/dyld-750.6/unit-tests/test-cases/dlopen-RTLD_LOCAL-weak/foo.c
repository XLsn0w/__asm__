

int __attribute__((weak)) A[] = { 5, 6, 7, 8 };

int* getA() { return A; }

int foo()
{
	return 10;
}

int main()
{
	return 0;
}


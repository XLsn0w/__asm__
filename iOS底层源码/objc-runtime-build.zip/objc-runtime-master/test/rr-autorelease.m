// TEST_CFLAGS -framework Foundation
// TEST_CONFIG MEM=mrc

#include "test.h"

#define FOUNDATION 0
#define NAME "rr-autorelease"

#include "rr-autorelease2.m"

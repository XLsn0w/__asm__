//
//  ARCMRC.h
//  TestARCLayouts
//
//  Created by Patrick Beard on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MRCBase.h"

@interface ARCMRC : MRCBase
@property(retain) id dataSource;
@end

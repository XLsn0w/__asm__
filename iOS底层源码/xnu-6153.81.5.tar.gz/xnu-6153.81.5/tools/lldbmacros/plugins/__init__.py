"""
Plugins that process other lldb macros' output
"""

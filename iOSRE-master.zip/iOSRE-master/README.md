# iOSRE

[![Join the chat at freenode:iOSRE](https://img.shields.io/badge/irc-freenode:%20%23%23iOSRE-blue.svg)](http://webchat.freenode.net/?channels=%23%23iOSRE) <br>
iOS Reverse Engineering

The aim of this project is to provide useful and updated tools and knowledge on iOS reverse engineering and exploitation.
This is an ongoing effort, and still in a very new stage.

You may contribute actual files by adding it to the "resources" folder.
Please note that these files are mostly user-contributed and may be malicious, so do your own homework before running them. If you see something bad we haven't noticed, please open an issue.

Thank you, and please join us at irc.freenode.net on `##iosre` for suggestions or plain idling

Welcome to the iOSRE wiki!

The aim of this wiki will be to provide detailed and updated information on reverse engineering iOS.
Any sort of content related to iOS related reverse engineering is allowed, as well as exploitation techniques and discussions on mitigation bypasses.

This is still very new, so at this point content may be incomplete or missing, but please join `##iOSRE` on Freenode if you have any suggestion or would like to see certain content.
